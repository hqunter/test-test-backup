import fs from "node:fs/promises";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const outDir = "D:/TESTTEST/outputs/20260915";
await fs.mkdir(outDir, { recursive: true });
const monthly = {
  2020:[1165.249,1193.637,1214.643,1221.186,1228.336,1206.340,1197.671,1185.885,1176.939,1143.811,1113.951,1093.669],
  2021:[1098.219,1111.065,1130.115,1117.214,1122.105,1122.449,1145.140,1160.706,1173.081,1182.430,1184.851,1184.117],
  2022:[1196.124,1198.113,1220.208,1236.886,1266.195,1277.639,1306.060,1320.323,1393.971,1425.417,1353.894,1291.819],
  2023:[1241.443,1277.101,1301.878,1319.695,1325.380,1293.095,1280.461,1320.561,1332.088,1347.617,1302.757,1299.860],
  2024:[1322.552,1329.691,1329.607,1366.818,1361.663,1377.143,1379.148,1347.332,1327.326,1359.125,1392.367,1436.657],
  2025:[1450.027,1441.287,1454.892,1435.938,1389.280,1365.166,1378.243,1388.467,1393.815,1422.902,1458.730,1464.380],
  2026:[1455.053,1448.107,1490.218,1483.932,1490.500,1529.707,1490.697,1405.210,1349.188]
};
const rows=[];
for (const y of Object.keys(monthly).map(Number)) for (let m=1;m<=monthly[y].length;m++) rows.push([new Date(Date.UTC(y,m-1,1)), y, m, monthly[y][m-1], null, "월평균"]);
async function firstTradingClose(symbol){
  const u=`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?period1=1577836800&period2=1789430400&interval=1d&events=history`;
  const j=await (await fetch(u)).json(); const r=j.chart.result[0]; const out=new Map();
  r.timestamp.forEach((ts,i)=>{const d=new Date(ts*1000); const k=`${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,"0")}`; const c=r.indicators.quote[0].close[i]; if(c!=null&&!out.has(k)) out.set(k,c);}); return out;
}
const [nasdaq,sp]=await Promise.all([firstTradingClose("^IXIC"),firstTradingClose("^GSPC")]);
for (const row of rows){const d=row[0], k=`${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,"0")}`; row.push(nasdaq.get(k)??null,sp.get(k)??null);}
const wb=Workbook.create(); const s=wb.worksheets.add("월별 환율"); s.showGridLines=false;
s.getRange("A1:K1").values=[["원/달러·NASDAQ·S&P 500 월별 변동","","","","","","","","","",""]];
s.getRange("A2:K2").merge(); s.getRange("A2").values=[["2020~2026 | 환율은 월평균 대표값, 지수는 매월 1일(휴장일은 첫 거래일) 종가"]];
s.getRange("A4:K4").values=[["기준일","연도","월","USD/KRW (월평균)","전월 대비 변동률","값 구분","NASDAQ 종합지수","S&P 500","차트용 환율 (시작=100)","차트용 NASDAQ (시작=100)","차트용 S&P 500 (시작=100)"]];
s.getRange(`A5:H${rows.length+4}`).values=rows;
s.getRange("I5:K5").formulas=[["=D5/$D$5*100","=G5/$G$5*100","=H5/$H$5*100"]]; s.getRange(`I5:K${rows.length+4}`).fillDown();
s.getRange("E5").values=[[null]];
s.getRange("E6").formulas=[["=D6/D5-1"]]; s.getRange(`E6:E${rows.length+4}`).fillDown();
s.getRange(`A${rows.length+6}:F${rows.length+9}`).values=[
  ["주의사항","","","","",""] ,
  ["월 1일이 주말·휴일인 경우를 포함하여, 각 월의 일별 중간환율 평균을 월 1일 대표값으로 표시했습니다.","","","","",""] ,
  ["출처","https://fxconverter.tech/usd-to-krw/history","","","",""] ,
  ["조회 기준일","2026-09-15","","","",""]
];
s.getRange("A1:K1").format={font:{name:"Arial",size:16,bold:true,color:"#1F2937"}};
s.getRange("A2:K2").format={font:{name:"Arial",size:10,italic:true,color:"#6B7280"}};
s.getRange("A4:K4").format={fill:"#1F4E78",font:{name:"Arial",size:10,bold:true,color:"#FFFFFF"},horizontalAlignment:"center",verticalAlignment:"center",wrapText:true};
s.getRange(`A5:K${rows.length+4}`).format={font:{name:"Arial",size:10,color:"#1F2937"},verticalAlignment:"center"};
s.getRange(`A5:A${rows.length+4}`).format.numberFormat="yyyy-mm-dd";
s.getRange(`D5:D${rows.length+4}`).format.numberFormat="#,##0.000";
s.getRange(`E5:E${rows.length+4}`).format.numberFormat="0.00%";
s.getRange(`E6:E${rows.length+4}`).conditionalFormats.add("colorScale",{colors:["#FECACA","#FFFFFF","#BBF7D0"],thresholds:["min",0,"max"]});
s.getRange(`A${rows.length+6}:F${rows.length+6}`).format={font:{name:"Arial",size:10,bold:true,color:"#1F2937"}};
s.getRange(`A${rows.length+7}:F${rows.length+9}`).format={font:{name:"Arial",size:9,italic:true,color:"#6B7280"},wrapText:true};
s.getRange(`A${rows.length+12}:K${rows.length+21}`).values=[
  ["시사점","","","","","","","","","",""] ,
  ["1. 세 계열을 첫 시점=100으로 환산해 절대 수준이 아닌 누적 방향과 상대 강도를 비교했습니다.","","","","","","","","","",""] ,
  ["2. 2020년에는 코로나 충격 이후 위험자산 지수가 빠르게 반등하는 흐름이 나타납니다.","","","","","","","","","",""] ,
  ["3. 2021년까지는 NASDAQ과 S&P 500의 상승 추세가 원/달러 환율보다 강했습니다.","","","","","","","","","",""] ,
  ["4. 2022년에는 두 주가지수의 조정과 달러 강세(원/달러 상승)가 함께 나타나는 구간입니다.","","","","","","","","","",""] ,
  ["5. 2023~2025년은 주가지수 회복·상승과 원/달러 환율 변동이 병존해 자산별 흐름이 달랐습니다.","","","","","","","","","",""] ,
  ["6. NASDAQ은 성장주 비중이 높아 S&P 500보다 변동성과 회복 탄력이 크게 나타나는 경향이 있습니다.","","","","","","","","","",""] ,
  ["7. 2026년은 조회 시점까지의 부분 기간이므로 연간 성과로 해석하지 않아야 합니다.","","","","","","","","","",""] ,
  ["8. 환율 상승은 원화 기준 해외자산 수익률을 높일 수 있지만, 달러자산 투자비용과 변동성도 키울 수 있습니다.","","","","","","","","","",""] ,
  ["9. 투자 판단 시 지수 수익률과 환율 효과를 분리해 보고, 기간·기준일·환전비용을 함께 고려해야 합니다.","","","","","","","","","",""]
];
s.getRange(`A${rows.length+12}:K${rows.length+12}`).format={font:{name:"Arial",size:10,bold:true,color:"#1F2937"}};
s.getRange(`A${rows.length+13}:K${rows.length+21}`).format={font:{name:"Arial",size:9,color:"#374151"},wrapText:true};
s.getRange("A:K").format.columnWidth=16; s.getRange("A:A").format.columnWidth=14; s.getRange("D:D").format.columnWidth=18; s.getRange("E:E").format.columnWidth=18; s.getRange("F:F").format.columnWidth=12; s.getRange("G:H").format.columnWidth=19; s.getRange("I:K").format.columnWidth=18;
s.getRange("G5:H88").format.numberFormat="#,##0.00";
s.getRange("I5:K88").format.numberFormat="#,##0.00";
s.getRange(`A4:K${rows.length+4}`).format.borders={insideHorizontal:{style:"thin",color:"#E5E7EB"},bottom:{style:"thin",color:"#D1D5DB"}};
s.freezePanes.freezeRows(4);
const chart=s.charts.add("line",[s.getRange(`A4:A${rows.length+4}`),s.getRange(`I4:I${rows.length+4}`),s.getRange(`J4:J${rows.length+4}`),s.getRange(`K4:K${rows.length+4}`)]); chart.title="원/달러·NASDAQ·S&P 500 추이 (시작점=100)"; chart.setPosition("M4","U22"); chart.legend={position:"top",textStyle:{typeface:"Arial"}};
const check=await wb.inspect({kind:"table",range:`월별 환율!A1:F12`,include:"values,formulas",tableMaxRows:12,tableMaxCols:6}); console.log(check.ndjson);
const errors=await wb.inspect({kind:"match",searchTerm:"#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!",options:{useRegex:true,maxResults:50},summary:"formula errors"}); console.log(errors.ndjson);
const preview=await wb.render({sheetName:"월별 환율",range:"A1:P20",scale:1,format:"png"}); await fs.writeFile(`${outDir}/preview.png`,new Uint8Array(await preview.arrayBuffer()));
const xlsx=await SpreadsheetFile.exportXlsx(wb); await xlsx.save(`${outDir}/USD_KRW_2020_2026_monthly_with_insights.xlsx`);
