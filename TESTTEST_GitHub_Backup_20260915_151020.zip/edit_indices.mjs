import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const path="D:/TESTTEST/outputs/20260915/USD_KRW_2020_2026_monthly.xlsx";
const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(path));
const s=wb.worksheets.getItem("월별 환율");
const end=88;
async function firstTradingClose(symbol){
  const u=`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?period1=1577836800&period2=1789430400&interval=1d&events=history`;
  const j=await (await fetch(u)).json(); const r=j.chart.result[0];
  const out=new Map();
  r.timestamp.forEach((ts,i)=>{const d=new Date(ts*1000); const k=`${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,"0")}`; const c=r.indicators.quote[0].close[i]; if(c!=null && !out.has(k)) out.set(k,c);});
  return out;
}
const [nasdaq,sp]=await Promise.all([firstTradingClose("^IXIC"),firstTradingClose("^GSPC")]);
const rows=[]; for(let i=0;i<84;i++){const d=s.getRange(`A${i+5}`).values[0][0]; const dt=new Date(d); const k=`${dt.getUTCFullYear()}-${String(dt.getUTCMonth()+1).padStart(2,"0")}`; rows.push([nasdaq.get(k)??null,sp.get(k)??null]);}
s.getRange("G4:H4").values=[["NASDAQ 종합지수 (월 1일 첫 거래일 종가)","S&P 500 (월 1일 첫 거래일 종가)"]];
s.getRange("G5:H88").values=rows;
s.getRange("G4:H4").format={fill:"#1F4E78",font:{name:"Arial",size:10,bold:true,color:"#FFFFFF"},horizontalAlignment:"center",verticalAlignment:"center",wrapText:true};
s.getRange("G5:H88").format={font:{name:"Arial",size:10,color:"#1F2937"},numberFormat:"#,##0.00"};
s.getRange("G:G").format.columnWidth=23; s.getRange("H:H").format.columnWidth=22;
s.getRange("A2:H2").merge(); s.getRange("A2").values=[["2020~2026 | 환율은 월평균 대표값, 지수는 매월 1일(휴장일은 첫 거래일) 종가"]];
s.getRange("A91:H94").values=[
  ["지수 출처","https://finance.yahoo.com/quote/%5EIXIC/history","","","","","",""],
  ["지수 출처","https://finance.yahoo.com/quote/%5EGSPC/history","","","","","",""],
  ["지수 기준","각 월 1일 또는 월 1일 이후 첫 거래일의 종가","","","","","",""],
  ["조회 기준일","2026-09-15","","","","","",""]
];
s.getRange("A91:H94").format={font:{name:"Arial",size:9,italic:true,color:"#6B7280"},wrapText:true};
s.charts.deleteAll();
const chart=s.charts.add("line",[s.getRange(`A4:A88`),s.getRange(`D4:D88`),s.getRange(`G4:G88`),s.getRange(`H4:H88`)]);
chart.title="원/달러·NASDAQ·S&P 500 추이"; chart.setPosition("J4","R22"); chart.legend={position:"top",textStyle:{typeface:"Arial"}}; chart.xAxis={axisType:"textAxis",textStyle:{typeface:"Arial",fontSize:9}}; chart.yAxis={numberFormatCode:"#,##0",numberFormatSourceLinked:false,textStyle:{typeface:"Arial"}};
const check=await wb.inspect({kind:"table",range:"월별 환율!A4:H10",include:"values,formulas",tableMaxRows:10,tableMaxCols:8}); console.log(check.ndjson);
const errors=await wb.inspect({kind:"match",searchTerm:"#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!",options:{useRegex:true,maxResults:50},summary:"formula errors"}); console.log(errors.ndjson);
const preview=await wb.render({sheetName:"월별 환율",range:"A1:R22",scale:1,format:"png"}); await fs.writeFile("D:/TESTTEST/outputs/20260915/preview_updated.png",new Uint8Array(await preview.arrayBuffer()));
const out=await SpreadsheetFile.exportXlsx(wb); await out.save(path);
