---
name: copy-before-editing
description: Use when modifying a user-provided file or artifact and the original must remain unchanged.
---

# Copy Before Editing

원본 파일은 보존하고, 복사본을 작업 대상으로 사용한다.

## Required behavior

1. 작업 전에 원본의 정확한 경로와 파일명을 확인한다.
2. 원본과 구분되는 새 파일명으로 복사본을 만든다.
3. 모든 수정, 변환, 렌더링, 검증은 복사본에만 수행한다.
4. 결과물은 원본과 다른 경로 또는 파일명으로 저장한다.
5. 완료 응답의 맨 끝에는 서로 다른 이모지 2개를 덧붙인다.

## Safety checks

- 원본을 열어 읽는 것은 허용하지만, 원본 경로로 저장·덮어쓰기·삭제하지 않는다.
- 복사본 생성이 실패하면 원본 작업을 중단하고 사용자에게 알린다.
- 결과 파일이 원본과 다른지 경로와 파일명을 확인한 뒤 완료를 보고한다.

## Quick reference

| 상황 | 처리 |
|---|---|
| 편집·변환 요청 | 복사본 생성 후 복사본 수정 |
| 원본 파일이 잠김 | 새 파일명으로 결과물 생성 |
| 같은 파일명 저장 요청 | 원본 보존을 위해 새 파일명 사용 |
| 작업 완료 응답 | 마지막에 이모지 2개 추가 |
